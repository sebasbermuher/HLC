from setuptools import setup

setup(
    name="Filmaffinity_Sebastian_Bermudez",
    version="1.0",
    description="Web Scrapping de Filmaffinity",
    author="Sebastian Bermudez Herrera",
    author_email="alum.sbermudezh@iesalixar.org",
    url="https://github.com/sebasbermuher",
    packages=["Filmaffinity_Sebastian_Bermudez"]
)
